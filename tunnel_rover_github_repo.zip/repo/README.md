# IoT-Based Tunnel Inspection Rover

> An ESP32-powered robotic rover designed for remote inspection of hazardous tunnel environments — featuring real-time gas detection, obstacle sensing, temperature monitoring, and live IoT dashboard control via Blynk.

![Rover Front View](images/rover_front.jpg)

---

## Project Overview

Traditional tunnel inspection requires humans to enter confined, potentially toxic environments. This rover eliminates that risk by providing real-time environmental monitoring and remote navigation from a safe distance using an IoT dashboard.

---

## Hardware Components

| Component | Model | Purpose |
|---|---|---|
| Microcontroller | ESP32 | Central processing + WiFi |
| Camera | ESP32-CAM | Live video streaming |
| Gas Sensor | MQ-2 / MQ Series | Smoke & gas detection |
| Temperature & Humidity | DHT11 | Ambient environment monitoring |
| Ultrasonic Sensor | HC-SR04 (Flying Fish) | Obstacle detection & distance |
| Motor Driver | L298N | PWM-based motor control |
| DC Gear Motors | 4x | 4-wheel drive locomotion |
| Power Supply | 18650 Li-ion (3000mAh VIPOW x3) | Portable power |
| Chassis | 4-wheel robot platform | Wooden laser-cut frame |
| Alert System | Red LED indicators | Visual hazard alerts |

---

## System Architecture

```
[Blynk App / Dashboard]
         |
       WiFi
         |
      [ESP32] ──── UART ──── [ESP32-CAM]  →  Live Video Stream
         |
    ┌────┴─────────────────────────────┐
    │                                  │
 [L298N Motor Driver]           [Sensor Array]
    │                                  │
 [4x DC Motors]          ┌────────────┼────────────┐
 (PWM Control)        [MQ Gas]   [DHT11]    [HC-SR04]
                       Sensor    Temp/Hum   Ultrasonic
```

---

## Communication Protocols Used

- **UART** — ESP32 ↔ ESP32-CAM serial communication
- **PWM** — Motor speed control via L298N driver
- **Digital I/O** — Sensor interfacing (DHT11, HC-SR04, MQ series)
- **WiFi / TCP-IP** — Blynk IoT cloud connectivity

---

## Features

- Remote rover control via Blynk mobile/web dashboard
- Live video feed from ESP32-CAM
- Real-time gas concentration readings with threshold alerts
- Temperature and humidity monitoring
- Obstacle detection using ultrasonic sensor
- LED-based visual hazard alert system
- 4-wheel drive for stable navigation on uneven surfaces

---

## Project Photos

<table>
  <tr>
    <td><img src="images/rover_top.jpg" width="350" alt="Top view — component layout"/><br/><em>Top view — component layout</em></td>
    <td><img src="images/rover_front.jpg" width="350" alt="Front view — sensor array"/><br/><em>Front view — sensor array</em></td>
  </tr>
  <tr>
    <td><img src="images/rover_side1.jpg" width="350" alt="Side view — full chassis"/><br/><em>Side view — full chassis</em></td>
    <td><img src="images/rover_side2.jpg" width="350" alt="Side view — wiring and modules"/><br/><em>Side view — wiring and modules</em></td>
  </tr>
</table>

---

## How to Set Up

### Prerequisites
- Arduino IDE 1.8+ or Arduino IDE 2.x
- ESP32 board package installed ([installation guide](https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html))

### Required Libraries
Install via Arduino IDE Library Manager:
```
Blynk
DHT sensor library (Adafruit)
BlynkSimpleEsp32
```

### Steps

1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/iot-tunnel-inspection-rover.git
   ```

2. Open `firmware/rover_main.ino` in Arduino IDE

3. Create a `config.h` file with your credentials:
   ```cpp
   #define WIFI_SSID     "your_wifi_name"
   #define WIFI_PASSWORD "your_wifi_password"
   #define BLYNK_TOKEN   "your_blynk_auth_token"
   ```

4. Select board: `ESP32 Dev Module` → Flash to ESP32

5. Open the Blynk app, create a new project, and configure virtual pins as per `firmware/blynk_config.md`

---

## Blynk Dashboard Pin Mapping

| Virtual Pin | Widget | Function |
|---|---|---|
| V0 | Joystick | Rover movement control |
| V1 | Value Display | Gas sensor reading |
| V2 | Value Display | Temperature (°C) |
| V3 | Value Display | Humidity (%) |
| V4 | Value Display | Ultrasonic distance (cm) |
| V5 | LED Widget | Hazard alert indicator |

---

## Applications

- Mining tunnel safety inspection
- Sewer and drainage pipeline inspection
- Post-disaster structural damage assessment
- Industrial confined-space hazard monitoring

---

## Author

**R E Kumaresan**  
B.Tech Electronics & Communication Engineering  
Siddartha Institute of Science and Technology (2021–2025)  

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue)](https://www.linkedin.com/in/r-e-kumaresan-9a4a59264)
[![Email](https://img.shields.io/badge/Email-kumaresanre7%40gmail.com-red)](mailto:kumaresanre7@gmail.com)

---

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
