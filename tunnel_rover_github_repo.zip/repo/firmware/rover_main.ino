/*
  IoT Tunnel Inspection Rover
  Author: R E Kumaresan
  Board:  ESP32 Dev Module
  IDE:    Arduino IDE
*/

#define BLYNK_TEMPLATE_ID   "YOUR_TEMPLATE_ID"
#define BLYNK_DEVICE_NAME   "Tunnel Rover"
#define BLYNK_AUTH_TOKEN    "YOUR_AUTH_TOKEN"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>

// --- WiFi credentials ---
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";

// --- Motor driver pins (L298N) ---
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 12
#define ENA 25   // PWM speed control - left motors
#define ENB 13   // PWM speed control - right motors

// --- Sensor pins ---
#define TRIG_PIN  5
#define ECHO_PIN  18
#define DHT_PIN   4
#define GAS_PIN   34   // Analog pin for MQ sensor
#define LED_PIN   2    // Onboard LED for alerts

// --- Thresholds ---
#define GAS_THRESHOLD  2000
#define SAFE_DISTANCE  20     // cm

DHT dht(DHT_PIN, DHT11);
BlynkTimer timer;

// --- Motor control ---
void moveForward(int speed) {
  analogWrite(ENA, speed); analogWrite(ENB, speed);
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
}
void moveBackward(int speed) {
  analogWrite(ENA, speed); analogWrite(ENB, speed);
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
}
void turnLeft(int speed) {
  analogWrite(ENA, speed); analogWrite(ENB, speed);
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
}
void turnRight(int speed) {
  analogWrite(ENA, speed); analogWrite(ENB, speed);
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
}
void stopMotors() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
}

// --- Blynk joystick (Virtual Pin V0) ---
BLYNK_WRITE(V0) {
  int x = param[0].asInt();
  int y = param[1].asInt();
  if      (y > 600) moveForward(200);
  else if (y < 400) moveBackward(200);
  else if (x < 400) turnLeft(180);
  else if (x > 600) turnRight(180);
  else              stopMotors();
}

// --- Read and send sensor data ---
void readSensors() {
  // DHT11
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();
  if (!isnan(temp)) Blynk.virtualWrite(V2, temp);
  if (!isnan(hum))  Blynk.virtualWrite(V3, hum);

  // Gas sensor
  int gas = analogRead(GAS_PIN);
  Blynk.virtualWrite(V1, gas);
  if (gas > GAS_THRESHOLD) {
    digitalWrite(LED_PIN, HIGH);
    Blynk.virtualWrite(V5, 1);   // LED widget ON
  } else {
    digitalWrite(LED_PIN, LOW);
    Blynk.virtualWrite(V5, 0);
  }

  // Ultrasonic distance
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH);
  int dist = duration * 0.034 / 2;
  Blynk.virtualWrite(V4, dist);
  if (dist < SAFE_DISTANCE) stopMotors();
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(ENA, OUTPUT); pinMode(ENB, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT); pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  Blynk.begin(BLYNK_AUTH_TOKEN, WIFI_SSID, WIFI_PASS);
  timer.setInterval(1000L, readSensors);
}

void loop() {
  Blynk.run();
  timer.run();
}
